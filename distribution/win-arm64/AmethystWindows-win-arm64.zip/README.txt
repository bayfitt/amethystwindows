AmethystWindows for Windows ARM64

This is a framework-dependent build. Install the .NET 10 Windows Desktop Runtime for ARM64 before running it.
Extract the complete archive and run AmethystWindows.exe.

Alt+Shift+Space toggles between Tall and Monocle.
For source build instructions and the ARM64 PE check, see BUILDING.md in the repository.
The repository also provides this archive's SHA-256 hash and SSH signature.